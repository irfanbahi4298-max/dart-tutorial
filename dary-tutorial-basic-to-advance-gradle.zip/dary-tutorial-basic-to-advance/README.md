# my_app

A Dart program, run on the device by the Dart SDK inside the Dart plugin.

- `bin/my_app.dart` is the program. Press Run: its output appears in the Run console, and what you type
  there is its standard input. Every `.dart` file in `bin/` gets a Run entry of its own.
- `lib/` holds the code the program imports as `package:my_app/...`.
- Add packages in `pubspec.yaml`, then pick `pub get` in the Run menu (Run also does it when the
  pubspec changed).
